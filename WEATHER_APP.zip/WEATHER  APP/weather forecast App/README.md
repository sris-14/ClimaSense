This ia a Weather Forcasting App.
In this app we detect the temperature of different countrys and citys and it give also next 24 hours weather update.
In this app we use the Google API Map. 